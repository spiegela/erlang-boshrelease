-module(some_known_remote).

-export_type([type42/0]).

-type type42() :: ok | ko.
