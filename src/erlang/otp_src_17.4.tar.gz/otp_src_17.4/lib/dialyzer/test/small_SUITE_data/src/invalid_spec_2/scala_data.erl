-module(scala_data).

-export_type([data/0]).

-opaque data() :: {'data', term()}.
