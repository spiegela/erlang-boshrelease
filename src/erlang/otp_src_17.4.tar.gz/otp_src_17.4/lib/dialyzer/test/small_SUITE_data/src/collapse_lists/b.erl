-module(b).
-export([f/1]).

-spec f(a:t()) -> a:t().
f(X) -> a:g(X).
