-module(zoltan_adt).

-export_type([id/0]).

-opaque id() :: string().
